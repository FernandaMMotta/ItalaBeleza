//
//  Map.swift
//  Ítala Beleza
//
//  Created by Fernanda Melero Motta on 13/07/17.
//  Copyright © 2017 Fernanda Melero Motta. All rights reserved.
//

import UIKit
import MapKit

let coordinateItalaBeleza = CLLocationCoordinate2D(latitude: -23.633268, longitude:  -46.530983)

let span = MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)

class Map: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    // MARK: - Outlets
    @IBOutlet weak var map: MKMapView!

    // MARK: - Properties
    let region = MKCoordinateRegion(center: coordinateItalaBeleza, span: span)


    // MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()

        configureLocationServices()
    }

    // MARK: - Actions

    // managing segmented control
    @IBAction func manageSegmentedControl(_ sender: UISegmentedControl) {

        switch sender.selectedSegmentIndex {

        case 0:
            self.map.mapType = .standard
        case 1:
            self.map.mapType = .satellite

        default:
            self.map.mapType = .standard
        }

    }

    // configuring user location
    @IBAction func rote(_ sender: UIButton) {

        //code
        

    }
    


    // MARK: - Methods

    // if we don't have permission, request
    var manager = CLLocationManager()
    func configureLocationServices() {

        self.manager.delegate = self

        let authorizationStatus = CLLocationManager.authorizationStatus()

        switch authorizationStatus {
        case .notDetermined, .denied:
            self.manager.requestWhenInUseAuthorization()
            self.manager.startUpdatingLocation()
            break
        case .authorizedAlways, .authorizedWhenInUse:
            addPoint(coordinate: coordinateItalaBeleza, title: "Ítala Beleza")
            break

        // Do nothing otherwise.
        default: break
        }

    }

    // managing location when change authorization
    func locationManager(_ manager: CLLocationManager,
                         didChangeAuthorization authorizationStatus: CLAuthorizationStatus) {

        switch  authorizationStatus{

        case .denied, .restricted:
            configureLocationServices()
            break

        // Do nothing otherwise.
        default: break
        }

    }

    // adding a point in map
    func addPoint(coordinate: CLLocationCoordinate2D, title: String){

        let pino = MKPointAnnotation()
        pino.title = title
        pino.coordinate = coordinate
        self.map.addAnnotation(pino)
        self.map.setRegion(region, animated: true)
    
    }

}
