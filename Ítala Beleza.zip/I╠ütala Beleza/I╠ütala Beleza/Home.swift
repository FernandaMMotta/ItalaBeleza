//
//  Home.swift
//  Ítala Beleza
//
//  Created by Fernanda Melero Motta on 12/07/17.
//  Copyright © 2017 Fernanda Melero Motta. All rights reserved.
//

import UIKit

class Home: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var mapStackView: UIStackView!
    @IBOutlet weak var scheduleStackView: UIStackView!
    @IBOutlet weak var teamStackView: UIStackView!
    @IBOutlet weak var servicesStackView: UIStackView!
    // BarButtonItems
    @IBOutlet weak var scheduleItem: UIBarButtonItem!
    @IBOutlet weak var servicesItem: UIBarButtonItem!
    @IBOutlet weak var teamItem: UIBarButtonItem!
    @IBOutlet weak var mapItem: UIBarButtonItem!


    // MARK: - Properties

    // MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()

    }

    // MARK: - Actions
    @IBAction func scheduleTapGestureRecognizer(_ sender: UITapGestureRecognizer) {

        if sender.delaysTouchesEnded == true {

            let scheduleViewController:UIViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Schedule") as UIViewController

            show(scheduleViewController, sender: nil)

        }


    }

    @IBAction func servicesTapGestureRecognizer(_ sender: UITapGestureRecognizer) {

        if sender.delaysTouchesEnded == true {

            let servicesViewController:UIViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Services") as UIViewController

            print(servicesViewController)

            show(servicesViewController, sender: nil)
        }
    }


    @IBAction func teamTapGestureRecognizer(_ sender: UITapGestureRecognizer) {

    }


    @IBAction func mapTapGestureRecognizer(_ sender: UITapGestureRecognizer) {

        if sender.delaysTouchesEnded == true {

            let mapViewController:UIViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Map") as UIViewController

            show(mapViewController, sender: nil)
        }
    }
    



    // MARK: - Methods
}
