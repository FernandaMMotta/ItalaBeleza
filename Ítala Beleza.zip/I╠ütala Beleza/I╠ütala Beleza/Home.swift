//
//  Home.swift
//  Ítala Beleza
//
//  Created by Fernanda Melero Motta on 12/07/17.
//  Copyright © 2017 Fernanda Melero Motta. All rights reserved.
//

import UIKit

class Home: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var mapaStackView: UIStackView!
    @IBOutlet weak var agendarStackView: UIStackView!
    @IBOutlet weak var equipeStackView: UIStackView!
    @IBOutlet weak var servicosStackView: UIStackView!
    @IBOutlet weak var agendarItem: UIToolbar!
    @IBOutlet weak var mapaItem: UIToolbar!


    // MARK: - Properties

    // MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()


    }

    // MARK: - Actions
    @IBAction func agendarTapGestureRecognizer(_ sender: UITapGestureRecognizer) {

        sender.numberOfTouchesRequired = 1

        if sender.numberOfTouches == 1{
        }


    }

    @IBAction func servicosTapGestureRecognizer(_ sender: UITapGestureRecognizer) {
    }


    @IBAction func equipeTapGestureRecognizer(_ sender: UITapGestureRecognizer) {
    }


    @IBAction func mapaTapGestureRecognizer(_ sender: UITapGestureRecognizer) {
    }
    



    // MARK: - Methods
}
