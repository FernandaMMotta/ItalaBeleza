//
//  Home.swift
//  Ítala Beleza
//
//  Created by Fernanda Melero Motta on 12/07/17.
//  Copyright © 2017 Fernanda Melero Motta. All rights reserved.
//

import UIKit

class Home: UIViewController {

    // MARK: - Outlets

    // MARK: - Properties

    // MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()



    }

    // MARK: - Actions


    // MARK: - Methods
}
