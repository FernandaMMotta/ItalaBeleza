//
//  Mapa.swift
//  Ítala Beleza
//
//  Created by Fernanda Melero Motta on 13/07/17.
//  Copyright © 2017 Fernanda Melero Motta. All rights reserved.
//

import UIKit
import MapKit

let coordenadasItalaBeleza = CLLocationCoordinate2D(latitude: -23.633268, longitude:  -46.530983)

let span = MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)

class Mapa: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    // MARK: - Outlets
    @IBOutlet weak var mapa: MKMapView!

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

    // MARK: - Properties
    
    let region = MKCoordinateRegion(center: coordenadasItalaBeleza, span: span)


    // MARK: - View Life Cycle
    override func viewDidAppear(_ animated: Bool) {

        let manager = CLLocationManager()
        let authorizationStatus = CLLocationManager.authorizationStatus()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest

        if(authorizationStatus == .notDetermined || authorizationStatus == .denied)
        {
            manager.requestWhenInUseAuthorization()
        }
    }

    // MARK: - Actions


    // MARK: - Methods

        func addPino(coordenadas: CLLocationCoordinate2D, titulo: String){
    
            let pino = MKPointAnnotation()
            //pino.title = titulo
            pino.title = "teste"
            //pino.coordinate = coordenadas
            pino.coordinate = coordenadasItalaBeleza
            self.mapa.addAnnotation(pino)
            self.mapa.setRegion(region, animated: true)
    
        }



}
