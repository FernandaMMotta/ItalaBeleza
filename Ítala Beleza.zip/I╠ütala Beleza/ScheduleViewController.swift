//
//  ScheduleViewController.swift
//  Ítala Beleza
//
//  Created by Fernanda Melero Motta on 14/07/17.
//  Copyright © 2017 Fernanda Melero Motta. All rights reserved.
//

import UIKit

class ScheduleViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var calendar: UIDatePicker!
    

    // MARK: - Properties

    // MARK: - View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()

        print(calendar.date.description(with: nil))
    }

    // MARK: - Actions

    // Mark: - Methods

    func updateDatePicker() {

        calendar.minimumDate = calendar.date

    }





    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
